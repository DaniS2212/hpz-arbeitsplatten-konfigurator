# Installation – Admin-Test 0.1.0

Dieses Paket ist eine geschlossene Vorschau, kein verkaufsfähiger Konfigurator. Kein Node-Server erforderlich. Bestehende Produkte, Texte, Galerien, WCPA-Formulare und Versandregeln werden nicht gespeichert oder verändert. Die lokale Demo bleibt erhalten.

1. ZIP unverändert herunterladen. Vor dem ersten Aktivierungstest eine aktuelle Sicherung bereithalten; bevorzugt mit Marco auf einer Testkopie prüfen. Ein echter WordPress-/Flatsome-Laufzeittest steht noch aus.
2. Als Administrator: **Plugins → Installieren → Plugin hochladen**, ZIP auswählen, **Jetzt installieren → Aktivieren**. WooCommerce muss aktiv sein, WordPress mindestens 6.5, PHP mindestens 7.4.
3. **Einstellungen → Arbeitsplatten-Vorschau** öffnen. **Vorschau aktivieren** anhaken, **Testmodus** angehakt lassen, Einbauort **Automatisch vor der Beschreibung**, speichern. Nach Installation ist die Vorschau standardmäßig aus. Testmodus auszuschalten schaltet die Vorschau aus, niemals den Verkauf frei.
4. **Produkte → Entwürfe**: Gerade 1000083, L 1000080 oder U 1000081 öffnen und **Vorschau** wählen. Nicht veröffentlichen. Als eingeloggter Administrator muss der Konfigurator zwischen Produktkopf und Beschreibung stehen.
5. Maße, Schritte, Dekor und Vergrößerung auf Desktop/Smartphone prüfen. Es erscheint kein verbindlicher Preis; „In den Warenkorb“ bleibt deaktiviert.
6. Falls Flatsome den Standard-Hook anders platziert: Einstellung **Nur Shortcode** wählen. In einem eigenen produktbezogenen UX-/Shortcode-Bereich zwischen Kopf und Beschreibung `[hpz_apl_configurator]` einsetzen. Bestehende Inhalte nicht ersetzen. Der Shortcode rendert nur auf dem jeweiligen erlaubten Entwurfsprodukt; keine ID-Parameter nötig. Nicht in globale Shopbereiche einbauen. Automatik und Shortcode sind gegenseitig ausgeschlossen.
7. Abgemeldet und als Kunde prüfen: keine Konfiguratorausgabe. Andere Produkte und Sockel 999985 gegen den bisherigen Stand vergleichen.

## Verhalten und Rücknahme

- Nur Administratorberechtigung `manage_options` plus Bearbeitungsrecht, nur Status `draft`, nur drei feste IDs. Eine veröffentlichte Produktseite erhält keine Vorschau.
- Solange das Plugin aktiv ist, sind diese drei IDs zusätzlich serverseitig nicht kaufbar, unabhängig von beiden Schaltern. Direkte Warenkorbversuche sowie vorhandene Zielpositionen im klassischen/Store-API-Warenkorb werden gesperrt. Andere Produkte bleiben unverändert.
- Plugin deaktivieren entfernt Einbettung UND dessen Kaufsperren. Deshalb Produkte weiterhin als Entwurf belassen. Keine automatische Veröffentlichung, Migration oder Rückübertragung.
- Keine Preisengine, Lieferanten-EK, Kundendaten oder externen Bild-/Fontdienste im Paket. Bestehende Dekore bleiben schematische SVG/CSS-Muster, keine Originaldekorfotos.
- WCPA muss für diese rein visuelle Testphase nichts importieren. Vorhandene Formulare und globale Einstellungen unverändert lassen.

## Noch vor Bestellintegration prüfen

PHP-Syntax/Aktivierung und WordPress-Sicherheitsgates in echter Laufzeit; installierte WooCommerce-/Flatsome-Version und Standard-Hook; Shortcodeposition; Admin-/Kunden-/Gastansicht; Cache darf keine Admin-Vorschau ausliefern; WP-Rocket-JS-Verzögerung/Minifizierung und CSP mit dynamischen Modulen; native Preis-/Kaufbereiche; Mobile/Tastatur; direkte klassische und Store-API-Kaufversuche; vorhandene Warenkörbe; Sockel-Regression. Für einen JavaScript-Optimierungskonflikt nur dieses Plugin gezielt von Optimierung ausnehmen, keine globalen Einstellungen ungeprüft ändern.

Erst später: WCPA-Feldadapter, verbindlich bestätigte Geometrien/Teile, serverseitiger Preis-/Geometrievalidator, Steuern, Gewicht, Kundenversand, Bestellmetadaten und gesonderte Verkaufsfreigabe. Browser-Vorschau ist keine serverseitige Fertigungsprüfung.
