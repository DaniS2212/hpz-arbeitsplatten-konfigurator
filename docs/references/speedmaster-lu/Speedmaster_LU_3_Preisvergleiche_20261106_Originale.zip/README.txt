Original-Speedmaster-Screenshots (06.11.2026), unmodified input bytes.
L2 488.01 EUR, U2 710.91 EUR, L1 links abgeschraegt (Kante durchlaufend) 510.02 EUR.
These are supplier-screen displayed amounts, not independently verified net supplier costs.
No manufacturing approval, no price/sale release. See accompanying GitHub JSON and documentation.
