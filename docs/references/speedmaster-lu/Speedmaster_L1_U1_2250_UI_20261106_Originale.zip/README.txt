ORIGINAL SPEEDMASTER & UI SCREENSHOTS - 5/6 NOVEMBER 2026

These four PNGs are the unmodified original user-supplied image bytes.
The two supplier screenshots are L1 and U1 at L1=2250 mm and 38mm W980, with the other dimensions in SOURCE_MANIFEST.csv.
Their displayed amounts, EUR 488.01 and EUR 715.04 respectively, exactly match the pre-existing length interpolation at the 2250mm holdout point.
A screenshot display is not independent documentation of whether the amount is a supplier NET purchasing price, nor a promise of manufacturing feasibility.
The other two images are UI feedback from a separate conversation: L4 B5 technical label & viewport scaling, and the default Woo product header to be simplified later.
Never bundle these images into publicly served WordPress plugin assets.

The ZIP intentionally preserves each PNG byte-for-byte. The manifest and GitHub handoff must be committed into the same private source repository.
