# Originale Speedmaster-Screenshots U1-U4, 05.11.2026

12 unveränderte PNG-Originaldateien aus dem Chat, je 3 je Variante.
Diese Bilder sind Hersteller-Sichtbelege, keine CNC-, Verpackungs- oder Preis-Freigabe.

Im GitHub-Repository unter docs/references/speedmaster-lu/ archivieren.
Nach dem Upload muss ein neuer Chat anhand der Prüfsummen und der SOURCE_MANIFEST.csv die Integrität prüfen.
Die Dateien dürfen weder in den WordPress-Plugin-Release noch in öffentliche Webseiten gelangen.
Die ZIP enthält zusätzlich die zwei übergebenen älteren Textkontexte als Primärmaterial, nicht als aktuell verbindlichen Stand. Für den aktuellen Stand gelten die separat versionierten Übergabe-Dokumente im Repository.
